<?php
// Database credentials
$host = 'localhost';
$dbname = 'qr_db';
$username = 'root';
$password = 'kartik123';

try {
    // Create a PDO connection
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Get the short code from the URL
    if (isset($_GET['code'])) {
        $code = $_GET['code'];

        // Retrieve the original URL from the database
        $stmt = $conn->prepare("SELECT original_url FROM urls WHERE short_code = :code LIMIT 1");
        $stmt->bindParam(':code', $code);
        $stmt->execute();

        if ($stmt->rowCount() > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            header("Location: " . $row['original_url']);
            exit();
        } else {
            echo "Invalid or expired URL.";
        }
    }
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>
