<?php
// Database credentials
$host = 'localhost';
$dbname = 'qr_db';
$username = 'root';
$password = 'kartik123';

try {
    // Create a PDO connection
    $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Function to generate a random short code
    function generateShortCode($length = 6) {
        return substr(str_shuffle('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, $length);
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $url = trim($_POST['url']);

        // Validate URL
        if (filter_var($url, FILTER_VALIDATE_URL)) {
            // Generate a unique short code
            $shortCode = generateShortCode();

            // Generate QR Code URL
            $shortUrl = "http://localhost/qr_generator/u/" . $shortCode;

            // Prepare query to insert the URL and short code
            $stmt = $conn->prepare("INSERT INTO urls (original_url, short_code, qr_code) VALUES (:url, :shortCode, :qrCode)");
            $stmt->bindParam(':url', $url);
            $stmt->bindParam(':shortCode', $shortCode);
            $stmt->bindParam(':qrCode', $shortUrl);

            if ($stmt->execute()) {
                echo json_encode(["success" => true, "short_url" => $shortUrl]);
            } else {
                echo json_encode(["success" => false, "message" => "Error saving URL."]);
            }
        } else {
            echo json_encode(["success" => false, "message" => "Invalid URL format."]);
        }
    }
} catch (PDOException $e) {
    echo json_encode(["success" => false, "message" => "Connection failed: " . $e->getMessage()]);
}
?>
